#!/bin/csh

#set echo

mv testpdgtran.lpt testpdgtran.lpt.bak
./testpdg
