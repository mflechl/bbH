/***  XDR I/O for entire dbin database ***/
/***  Generated automatically using the dbin tool. */
/***  Not to be modified by user. */
#include "mcf_ntubldXDRinc.h"

void mcf_ntubld_xdr_all(XDR* xdrs);

void mcf_ntubld_xdr_all(XDR* xdrs)
{
}
