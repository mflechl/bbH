/*******************************************************************************
*									       *
* mcf_BrowseMainMenu.h -- Main Menu Bar for the Mcfio Data Browser		       *			       *
*									       *
* Copyright (c) 1995, 1996 Universities Research Association, Inc.	       *
* All rights reserved.							       *
* 									       *
*******************************************************************************/extern Widget MainPanelW;
Widget mcfioC_CreateBrMenu(Widget panel);
